#pragma once

#ifndef STRING_TOOLS_H
#define STRING_TOOLS_H
#include <stdio.h>

int read_line(FILE *fp, char str[], int n);

#endif

//ifndef endif 지시어 이용하여 헤더파일 중복 include 방지